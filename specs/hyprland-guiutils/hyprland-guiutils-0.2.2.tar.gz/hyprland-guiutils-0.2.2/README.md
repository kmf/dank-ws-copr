# hyprland-guiutils
Hyprland GUI utilities (successor to hyprland-qtutils)
