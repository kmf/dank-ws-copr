/**
Copyright (C) 2025  Matthew Kosarek

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/

#ifndef MIRACLE_WM_CONFIG_CURSOR_FOCUS_MODE_H
#define MIRACLE_WM_CONFIG_CURSOR_FOCUS_MODE_H

#include "export.h"
#include <array>

namespace miracle
{
enum class MIRACLE_WM_CONFIG_API CursorFocusMode
{
    Hover = 0,
    Click,
    MAX
};

constexpr std::array<const char*, static_cast<int>(CursorFocusMode::MAX)> cursor_focus_mode_strings = {
    "hover",
    "click"
};

}

#endif // MIRACLE_WM_CONFIG_CURSOR_FOCUS_MODE_H
