/*
 * Copyright © Canonical Ltd.
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 or 3 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "compositor_state.h"
#include "config.h"
#include "leaf_container.h"
#include "mir/geometry/forward.h"
#include "mir_toolkit/common.h"
#include "mock_container.h"
#include "mock_output_factory.h"
#include "mock_session.h"
#include "mock_shell_application_spawner.h"
#include "mock_surface.h"
#include "mock_window_controller.h"
#include "mock_workspace.h"
#include "output_manager.h"
#include "parent_container.h"
#include "shell_application_manager.h"
#include "stub_configuration.h"
#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include <memory>
#include <miral/application.h>
#include <miral/window.h>

using namespace miracle;
using namespace testing;
namespace geom = mir::geometry;

class ParentContainerData
{
public:
    ParentContainerData(
        std::shared_ptr<ShellApplicationManager> const& shell_application_manager,
        std::shared_ptr<CompositorState> const& state,
        std::shared_ptr<WindowController> const& window_controller,
        std::shared_ptr<Config> const& config,
        geom::Rectangle const& area) :
        parent(std::make_shared<ParentContainer>(shell_application_manager, state, window_controller, config, area, workspace, nullptr))
    {
    }

    std::shared_ptr<test::MockWorkspace> workspace = std::make_shared<test::MockWorkspace>();
    geom::Rectangle area;
    std::shared_ptr<ParentContainer> parent;
};

class ParentContainerTest : public Test
{
public:
    [[nodiscard]] ParentContainerData make_parent(geom::Rectangle const& area) const
    {
        return ParentContainerData { shell_application_manager, state, window_controller, config, area };
    }

    std::shared_ptr<ShellApplicationManager> shell_application_manager = std::make_shared<ShellApplicationManager>(
        std::make_unique<NiceMock<test::MockShellApplicationSpawner>>());
    std::shared_ptr<CompositorState> state = std::make_shared<CompositorState>();
    std::shared_ptr<test::MockWindowController> window_controller = std::make_shared<testing::NiceMock<test::MockWindowController>>();
    std::shared_ptr<Config> config = std::make_shared<test::StubConfiguration>();
    std::shared_ptr<test::MockWorkspace> workspace = std::make_shared<test::MockWorkspace>();
};

class ParentContainerSwapTest : public ParentContainerTest
{
public:
    ParentContainerSwapTest()
    {
        first_parent_data.parent->add_child(container1, 0);
        second_parent_data.parent->add_child(container2, 0);
        second_parent_data.parent->add_child(container3, 1);
    }

    ParentContainerData const first_parent_data = make_parent(geom::Rectangle({ 0, 0 }, { 800, 800 }));
    ParentContainerData const second_parent_data = make_parent(geom::Rectangle({ 800, 0 }, { 1200, 800 }));
    std::shared_ptr<test::MockContainer> const container1 = std::make_shared<NiceMock<test::MockContainer>>();
    std::shared_ptr<test::MockContainer> const container2 = std::make_shared<NiceMock<test::MockContainer>>();
    std::shared_ptr<test::MockContainer> const container3 = std::make_shared<NiceMock<test::MockContainer>>();
};

TEST_F(ParentContainerSwapTest, SwapContainersBetweenParentsSetsParents)
{
    // We're allowing the leak because GMock is mad for a reason that
    // we don't currently care much about
    Mock::AllowLeak(container1.get());
    Mock::AllowLeak(container2.get());
    Mock::AllowLeak(container3.get());

    // Act: Swap the containers on different parent
    EXPECT_CALL(*container1, set_parent(Eq(second_parent_data.parent)));
    EXPECT_CALL(*container2, set_parent(Eq(first_parent_data.parent)));

    ParentContainer::swap(
        first_parent_data.parent,
        0,
        second_parent_data.parent,
        0);
}

TEST_F(ParentContainerSwapTest, SwapContainersBetweenParentsSetsWorkspaces)
{
    // We're allowing the leak because GMock is mad for a reason that
    // we don't currently care much about
    Mock::AllowLeak(container1.get());
    Mock::AllowLeak(container2.get());
    Mock::AllowLeak(container3.get());

    // Act: Swap the containers on different parent
    EXPECT_CALL(*container1, set_workspace(Eq(second_parent_data.workspace)));
    EXPECT_CALL(*container2, set_workspace(Eq(first_parent_data.workspace)));

    ParentContainer::swap(
        first_parent_data.parent,
        0,
        second_parent_data.parent,
        0);
}

TEST_F(ParentContainerSwapTest, SwapContainersBetweenParentsSetsLogicalArea)
{
    // We're allowing the leak because GMock is mad for a reason that
    // we don't currently care much about
    Mock::AllowLeak(container1.get());
    Mock::AllowLeak(container2.get());
    Mock::AllowLeak(container3.get());

    // Act: Swap the containers on different parent
    geom::Rectangle first_rectangle({ 0, 0 }, { 800, 800 });
    geom::Rectangle second_rectangle({ 800, 0 }, { 600, 800 });
    EXPECT_CALL(*container1, get_logical_area)
        .WillOnce(Return(first_rectangle));
    EXPECT_CALL(*container2, get_logical_area)
        .WillOnce(Return(second_rectangle));
    EXPECT_CALL(*container1, set_logical_area(Eq(second_rectangle), testing::_));
    EXPECT_CALL(*container2, set_logical_area(Eq(first_rectangle), testing::_));

    ParentContainer::swap(
        first_parent_data.parent,
        0,
        second_parent_data.parent,
        0);
}

TEST_F(ParentContainerSwapTest, SwapContainersBetweenParentsOnDifferentWorkspacesCausesTransformChange)
{
    // We're allowing the leak because GMock is mad for a reason that
    // we don't currently care much about
    Mock::AllowLeak(container1.get());
    Mock::AllowLeak(container2.get());
    Mock::AllowLeak(container3.get());

    // Act: Swap the containers on different parent
    EXPECT_CALL(*container1, set_workspace(testing::_));
    EXPECT_CALL(*container2, set_workspace(testing::_));

    ParentContainer::swap(
        first_parent_data.parent,
        0,
        second_parent_data.parent,
        0);
}

// ---- urgency ----

TEST_F(ParentContainerTest, ToJsonIsNotUrgentWhenNoChildIsUrgent)
{
    ParentContainerData const parent_data = make_parent(geom::Rectangle({ 0, 0 }, { 800, 800 }));
    auto const child = std::make_shared<NiceMock<test::MockContainer>>();
    ON_CALL(*child, to_json(_)).WillByDefault(Return(nlohmann::json({
        { "urgent", false }
    })));
    parent_data.parent->add_child(child, 0);
    Mock::AllowLeak(child.get());

    EXPECT_FALSE(parent_data.parent->to_json(true)["urgent"]);
}

TEST_F(ParentContainerTest, ToJsonIsUrgentWhenAnyChildIsUrgent)
{
    ParentContainerData const parent_data = make_parent(geom::Rectangle({ 0, 0 }, { 800, 800 }));
    auto const quiet = std::make_shared<NiceMock<test::MockContainer>>();
    auto const urgent = std::make_shared<NiceMock<test::MockContainer>>();
    ON_CALL(*quiet, to_json(_)).WillByDefault(Return(nlohmann::json({
        { "urgent", false }
    })));
    ON_CALL(*urgent, to_json(_)).WillByDefault(Return(nlohmann::json({
        { "urgent", true }
    })));
    parent_data.parent->add_child(quiet, 0);
    parent_data.parent->add_child(urgent, 1);
    Mock::AllowLeak(quiet.get());
    Mock::AllowLeak(urgent.get());

    EXPECT_TRUE(parent_data.parent->to_json(true)["urgent"]);
}

/// A child is not obliged to report urgency at all, so the aggregation must not
/// index a key that may be missing.
TEST_F(ParentContainerTest, ToJsonIsNotUrgentWhenAChildOmitsTheUrgentKey)
{
    ParentContainerData const parent_data = make_parent(geom::Rectangle({ 0, 0 }, { 800, 800 }));
    auto const child = std::make_shared<NiceMock<test::MockContainer>>();
    ON_CALL(*child, to_json(_)).WillByDefault(Return(nlohmann::json::object()));
    parent_data.parent->add_child(child, 0);
    Mock::AllowLeak(child.get());

    EXPECT_FALSE(parent_data.parent->to_json(true)["urgent"]);
}
