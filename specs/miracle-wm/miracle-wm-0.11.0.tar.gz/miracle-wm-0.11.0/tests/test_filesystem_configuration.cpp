/**
Copyright (C) 2025  Matthew Kosarek

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/

#include "config.h"
#include "config_observer.h"
#include "yaml-cpp/yaml.h"
#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <gmock/gmock-function-mocker.h>
#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include <miracle/cpp/animation_definition.h>
#include <miracle/cpp/modifiers.h>
#include <miral/runner.h>
#include <vector>
#include <xkbcommon/xkbcommon-keysyms.h>
#include <yaml-cpp/node/node.h>

using namespace miracle;

namespace
{
const std::string path = std::filesystem::current_path() / "test.yaml";
}

class FilesystemConfigurationTest : public testing::Test
{
public:
    void SetUp() override
    {
        std::ofstream ofs;
        ofs.open(path, std::ofstream::out | std::ofstream::trunc);
        ofs.close();
    }

    void TearDown() override
    {
        std::filesystem::remove(path.c_str());
    }

    void write_kvp(std::string key, std::string value)
    {
        std::fstream file(path, std::ios::app);
        file << key << ": " << value << "\n";
    }

    void write_yaml_node(YAML::Node const& node)
    {
        std::fstream file(path, std::ios::app);
        file << node;
    }

    std::shared_ptr<ConfigObserverRegistrar> registrar = std::make_shared<ConfigObserverRegistrar>();
};

TEST_F(FilesystemConfigurationTest, ConfigurationLoadingDoesNotFailWhenFileDoesNotExist)
{
    std::filesystem::remove(path.c_str());
    EXPECT_NO_THROW(FilesystemConfiguration config(registrar, path, true));
}

TEST_F(FilesystemConfigurationTest, ConfigurationLoadingDoesNotFailWhenFileDoesNotContainYaml)
{
    std::fstream file(path, std::ios::app);
    file << "Hello my name is Matthew { \"fifteen\": 15 } Goodbye then!";
    EXPECT_NO_THROW(FilesystemConfiguration config(registrar, path, true));
}

TEST_F(FilesystemConfigurationTest, DefaultModifierIsMeta)
{
    FilesystemConfiguration config(registrar, path, true);
    ASSERT_EQ(config.get_input_event_modifier(), mir_input_event_modifier_meta);
}

TEST_F(FilesystemConfigurationTest, CanWriteDefaultModifier)
{
    write_kvp("action_key", "alt");
    FilesystemConfiguration config(registrar, path, true);
    ASSERT_EQ(config.get_input_event_modifier(), mir_input_event_modifier_alt);
}

TEST_F(FilesystemConfigurationTest, UnknownModifiersResultsInMeta)
{
    write_kvp("action_key", "unknown");
    FilesystemConfiguration config(registrar, path, true);
    ASSERT_EQ(config.get_input_event_modifier(), mir_input_event_modifier_meta);
}

TEST_F(FilesystemConfigurationTest, WhenDefaultActionOverridesIsNotArrayThenWeDoNotFail)
{
    write_kvp("default_action_overrides", "hello");
    EXPECT_NO_THROW(FilesystemConfiguration config(registrar, path, true));
}

TEST_F(FilesystemConfigurationTest, CanOverrideDefaultAction)
{
    YAML::Node node;
    YAML::Node action_override_node;
    action_override_node["name"] = "terminal";
    action_override_node["action"] = "down";
    action_override_node["modifiers"].push_back("primary");
    action_override_node["key"] = "x";
    node["default_action_overrides"].push_back(action_override_node);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    config.matches_key_command(
        MirKeyboardAction::mir_keyboard_action_down,
        XKB_KEY_x,
        mir_input_event_modifier_meta,
        [&](DefaultKeyCommand command)
    {
        EXPECT_EQ(DefaultKeyCommand::Terminal, command);
        return true;
    });
}

TEST_F(FilesystemConfigurationTest, WhenEntryInDefaultActionOverridesHasInvalidNameThenItIsNotAdded)
{
    YAML::Node node;
    YAML::Node action_override_node;
    action_override_node["name"].push_back("terminal");
    action_override_node["action"] = "down";
    action_override_node["modifiers"].push_back("primary");
    action_override_node["key"] = "x";
    node["default_action_overrides"].push_back(action_override_node);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    config.matches_key_command(
        MirKeyboardAction::mir_keyboard_action_down,
        XKB_KEY_Return,
        mir_input_event_modifier_meta,
        [&](DefaultKeyCommand command)
    {
        EXPECT_EQ(DefaultKeyCommand::Terminal, command);
        return true;
    });
}

TEST_F(FilesystemConfigurationTest, WhenEntryInDefaultActionOverridesHasInvalidModifiersThenItIsNotAdded)
{
    YAML::Node node;
    YAML::Node action_override_node;
    action_override_node["name"] = "terminal";
    action_override_node["action"] = "down";
    action_override_node["modifiers"] = "primary";
    action_override_node["key"] = "x";
    node["default_action_overrides"].push_back(action_override_node);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    config.matches_key_command(
        MirKeyboardAction::mir_keyboard_action_down,
        XKB_KEY_Return,
        mir_input_event_modifier_meta,
        [&](DefaultKeyCommand command)
    {
        EXPECT_EQ(DefaultKeyCommand::Terminal, command);
        return true;
    });
}

TEST_F(FilesystemConfigurationTest, CanCreateCustomAction)
{
    YAML::Node node;
    YAML::Node action_override_node;
    action_override_node["command"] = "echo Hi";
    action_override_node["action"] = "down";
    action_override_node["modifiers"].push_back("primary");
    action_override_node["key"] = "x";
    node["custom_actions"].push_back(action_override_node);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    auto custom_action = config.matches_custom_key_command(
        MirKeyboardAction::mir_keyboard_action_down,
        XKB_KEY_x,
        mir_input_event_modifier_meta);
    EXPECT_EQ(custom_action->command, "echo Hi");
    EXPECT_EQ(custom_action->key, XKB_KEY_x);
    EXPECT_EQ(custom_action->action, mir_keyboard_action_down);
}

TEST_F(FilesystemConfigurationTest, DefaultKeyBindingsAreReported)
{
    FilesystemConfiguration config(registrar, path, true);
    auto const bindings = config.describe_key_bindings();
    ASSERT_EQ(bindings.size(), static_cast<size_t>(DefaultKeyCommand::MAX));

    auto const terminal = std::find_if(bindings.begin(), bindings.end(), [](KeyBindingInfo const& info)
    {
        return info.default_key_command == DefaultKeyCommand::Terminal;
    });
    ASSERT_NE(terminal, bindings.end());
    EXPECT_EQ(terminal->source, KeyBindingSource::built_in_default);
    EXPECT_EQ(terminal->keysym, XKB_KEY_Return);
    EXPECT_EQ(terminal->action, mir_keyboard_action_down);
    EXPECT_EQ(terminal->modifiers, static_cast<uint>(mir_input_event_modifier_meta));
    EXPECT_TRUE(terminal->command.empty());
}

TEST_F(FilesystemConfigurationTest, CustomKeyBindingsAreReported)
{
    YAML::Node node;
    YAML::Node custom_action_node;
    custom_action_node["command"] = "echo Hi";
    custom_action_node["action"] = "down";
    custom_action_node["modifiers"].push_back("primary");
    custom_action_node["key"] = "x";
    node["custom_actions"].push_back(custom_action_node);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    auto const bindings = config.describe_key_bindings();
    ASSERT_EQ(bindings.size(), static_cast<size_t>(DefaultKeyCommand::MAX) + 1);

    // Custom actions are attempted first, so they are emitted first.
    EXPECT_EQ(bindings[0].source, KeyBindingSource::custom);
    EXPECT_EQ(bindings[0].command, "echo Hi");
    EXPECT_EQ(bindings[0].keysym, XKB_KEY_x);
    EXPECT_EQ(bindings[0].action, mir_keyboard_action_down);
    EXPECT_EQ(bindings[0].default_key_command, DefaultKeyCommand::MAX);
    EXPECT_EQ(bindings[0].modifiers, static_cast<uint>(mir_input_event_modifier_meta));
}

TEST_F(FilesystemConfigurationTest, BuiltInOverridesAreAdditiveInKeyBindings)
{
    YAML::Node node;
    YAML::Node action_override_node;
    action_override_node["name"] = "terminal";
    action_override_node["action"] = "down";
    action_override_node["modifiers"].push_back("primary");
    action_override_node["key"] = "Escape";
    node["default_action_overrides"].push_back(action_override_node);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    auto const bindings = config.describe_key_bindings();
    ASSERT_EQ(bindings.size(), static_cast<size_t>(DefaultKeyCommand::MAX) + 1);

    // matches_key_command tries the overrides and then the *whole* default table,
    // so the original default binding still fires. Both must be reported.
    std::vector<KeyBindingInfo> terminals;
    for (auto const& info : bindings)
    {
        if (info.default_key_command == DefaultKeyCommand::Terminal)
            terminals.push_back(info);
    }
    ASSERT_EQ(terminals.size(), 2u);
    EXPECT_EQ(terminals[0].source, KeyBindingSource::built_in_override);
    EXPECT_EQ(terminals[0].keysym, XKB_KEY_Escape);
    EXPECT_EQ(terminals[1].source, KeyBindingSource::built_in_default);
    EXPECT_EQ(terminals[1].keysym, XKB_KEY_Return);
}

TEST_F(FilesystemConfigurationTest, PrimaryModifierIsResolvedInKeyBindings)
{
    write_kvp("action_key", "alt");

    FilesystemConfiguration config(registrar, path, true);
    auto const bindings = config.describe_key_bindings();
    ASSERT_FALSE(bindings.empty());

    auto const terminal = std::find_if(bindings.begin(), bindings.end(), [](KeyBindingInfo const& info)
    {
        return info.default_key_command == DefaultKeyCommand::Terminal;
    });
    ASSERT_NE(terminal, bindings.end());
    EXPECT_EQ(terminal->modifiers, static_cast<uint>(mir_input_event_modifier_alt));
    EXPECT_TRUE(terminal->configured_modifiers & miracle_input_event_modifier_default);
    EXPECT_FALSE(terminal->modifiers & miracle_input_event_modifier_default);
}

TEST_F(FilesystemConfigurationTest, KeyBindingsDoNotDeadlock)
{
    FilesystemConfiguration config(registrar, path, true);

    // matches_key_command invokes the callback without holding the mutex, but
    // describe_key_bindings must not reintroduce a lock-under-lock path either.
    // If it does, this hangs until the ctest timeout.
    bool called = false;
    config.matches_key_command(
        mir_keyboard_action_down,
        XKB_KEY_Return,
        mir_input_event_modifier_meta,
        [&](DefaultKeyCommand)
    {
        called = true;
        EXPECT_FALSE(config.describe_key_bindings().empty());
        return true;
    });
    EXPECT_TRUE(called);
}

TEST_F(FilesystemConfigurationTest, CustomActionsInSnapIncludeUnsnapCommand)
{
    setenv("SNAP", "test", 1);
    YAML::Node node;
    YAML::Node action_override_node;
    action_override_node["command"] = "echo Hi";
    action_override_node["action"] = "down";
    action_override_node["modifiers"].push_back("primary");
    action_override_node["key"] = "x";
    node["custom_actions"].push_back(action_override_node);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    auto custom_action = config.matches_custom_key_command(
        MirKeyboardAction::mir_keyboard_action_down,
        XKB_KEY_x,
        mir_input_event_modifier_meta);
    EXPECT_EQ(custom_action->command, "echo Hi");
    unsetenv("SNAP");
}

TEST_F(FilesystemConfigurationTest, CustomActionWithInvalidCommandIsNotAdded)
{
    YAML::Node node;
    YAML::Node action_override_node;
    action_override_node["command"].push_back("echo Hi");
    action_override_node["action"] = "down";
    action_override_node["modifiers"].push_back("primary");
    action_override_node["key"] = "x";
    node["custom_actions"].push_back(action_override_node);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    auto custom_action = config.matches_custom_key_command(
        MirKeyboardAction::mir_keyboard_action_down,
        XKB_KEY_x,
        mir_input_event_modifier_meta);
    EXPECT_EQ(custom_action, nullptr);
}

TEST_F(FilesystemConfigurationTest, InvalidInnerGapsResolveToDefault)
{
    YAML::Node node;
    YAML::Node vec;
    vec["x"] = "hello";
    vec["y"] = "goodbye";
    node["inner_gaps"] = vec;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_inner_gaps().left, 10);
    EXPECT_EQ(config.get_inner_gaps().top, 10);
}

TEST_F(FilesystemConfigurationTest, ValidInnerGapsAreSetCorrectly)
{
    YAML::Node node;
    YAML::Node vec;
    vec["x"] = 33;
    vec["y"] = 44;
    node["inner_gaps"] = vec;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_inner_gaps().left, 33);
    EXPECT_EQ(config.get_inner_gaps().top, 44);
}

TEST_F(FilesystemConfigurationTest, InvalidOuterGapsResolveToDefault)
{
    YAML::Node node;
    YAML::Node vec;
    vec["x"] = "hello";
    vec["y"] = "goodbye";
    node["outer_gaps"] = vec;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_outer_gaps().left, 10);
    EXPECT_EQ(config.get_outer_gaps().top, 10);
}

TEST_F(FilesystemConfigurationTest, ValidOuterGapsAreSetCorrectly)
{
    YAML::Node node;
    YAML::Node vec;
    vec["x"] = 33;
    vec["y"] = 44;
    node["outer_gaps"] = vec;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_outer_gaps().left, 33);
    EXPECT_EQ(config.get_outer_gaps().top, 44);
}

TEST_F(FilesystemConfigurationTest, ValidStartupAppsAreParsed)
{
    YAML::Node node;
    YAML::Node startup_app;
    startup_app["command"] = "echo Hi";
    startup_app["restart_on_death"] = true;
    node["startup_apps"].push_back(startup_app);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_startup_apps().size(), 1);
    EXPECT_EQ(config.get_startup_apps()[0].command, "echo Hi");
    EXPECT_EQ(config.get_startup_apps()[0].restart_on_death, true);
}

TEST_F(FilesystemConfigurationTest, StartupAppsInSnapIncludeUnsnapCommand)
{
    setenv("SNAP", "test", 1);
    YAML::Node node;
    YAML::Node startup_app;
    startup_app["command"] = "echo Hi";
    startup_app["restart_on_death"] = true;
    node["startup_apps"].push_back(startup_app);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_startup_apps()[0].command, "echo Hi");
    unsetenv("SNAP");
}

TEST_F(FilesystemConfigurationTest, StartupAppsThatIsNotAnArrayIsNotParsed)
{
    YAML::Node node;
    YAML::Node startup_app;
    node["startup_apps"] = "Hello";
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_startup_apps().size(), 0);
}

TEST_F(FilesystemConfigurationTest, StartupAppsInvalidCommandIsNotParsed)
{
    YAML::Node node;
    YAML::Node startup_app;
    startup_app["command"].push_back("Hello");
    startup_app["restart_on_death"] = false;
    node["startup_apps"].push_back(startup_app);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_startup_apps().size(), 0);
}

TEST_F(FilesystemConfigurationTest, StartupAppsInvalidRestartOnDeathIsNotParsed)
{
    YAML::Node node;
    YAML::Node startup_app;
    startup_app["command"] = "echo Hi";
    startup_app["restart_on_death"] = "Hello";
    node["startup_apps"].push_back(startup_app);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_startup_apps().size(), 0);
}

TEST_F(FilesystemConfigurationTest, EnvironmentVariableInvalidWhenKeyIsMissing)
{
    YAML::Node node;
    YAML::Node environment_variable;
    environment_variable["value"] = "1";
    node["environment_variables"].push_back(environment_variable);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_env_variables().size(), 0);
}

TEST_F(FilesystemConfigurationTest, EnvironmentVariableInvalidWhenValueIsMissing)
{
    YAML::Node node;
    YAML::Node environment_variable;
    environment_variable["key"] = "my_key";
    node["environment_variables"].push_back(environment_variable);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_env_variables().size(), 0);
}

TEST_F(FilesystemConfigurationTest, EnvironmentVariableCanBeParsed)
{
    YAML::Node node;
    YAML::Node environment_variable;
    environment_variable["key"] = "my_key";
    environment_variable["value"] = "1";
    node["environment_variables"].push_back(environment_variable);
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_env_variables().size(), 1);
}

TEST_F(FilesystemConfigurationTest, BackgroundColorDefaultsToGrayWhenUnset)
{
    YAML::Node node;
    node["resize_jump"] = 100;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.background_color().r, 46.f / 255.f);
    EXPECT_EQ(config.background_color().g, 52.f / 255.f);
    EXPECT_EQ(config.background_color().b, 54.f / 255.f);
}

TEST_F(FilesystemConfigurationTest, BackgroundColorCanBeParsedFromHex)
{
    YAML::Node node;
    node["background_color"] = "0xDD89DD";
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.background_color().r, 221.f / 255.f);
    EXPECT_EQ(config.background_color().g, 137.f / 255.f);
    EXPECT_EQ(config.background_color().b, 221.f / 255.f);
}

TEST_F(FilesystemConfigurationTest, BackgroundColorIgnoresAlphaInHex)
{
    YAML::Node node;
    node["background_color"] = "0xDD89DD00";
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.background_color().r, 221.f / 255.f);
    EXPECT_EQ(config.background_color().g, 137.f / 255.f);
    EXPECT_EQ(config.background_color().b, 221.f / 255.f);
}

TEST_F(FilesystemConfigurationTest, BackgroundColorCanBeParsedFromArray)
{
    YAML::Node color_node;
    color_node.push_back(255);
    color_node.push_back(155);
    color_node.push_back(55);

    YAML::Node node;
    node["background_color"] = color_node;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.background_color().r, 1.f);
    EXPECT_EQ(config.background_color().g, 155.f / 255.f);
    EXPECT_EQ(config.background_color().b, 55.f / 255.f);
}

TEST_F(FilesystemConfigurationTest, BackgroundColorCanBeParsedFromMap)
{
    YAML::Node color_node;
    color_node["r"] = 255;
    color_node["g"] = 155;
    color_node["b"] = 55;

    YAML::Node node;
    node["background_color"] = color_node;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.background_color().r, 1.f);
    EXPECT_EQ(config.background_color().g, 155.f / 255.f);
    EXPECT_EQ(config.background_color().b, 55.f / 255.f);
}

TEST_F(FilesystemConfigurationTest, MalformedBackgroundColorProducesAnError)
{
    YAML::Node node;
    node["background_color"] = "0xDD8";
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_FALSE(config.get_config_errors().empty());
}

TEST_F(FilesystemConfigurationTest, BorderCanBeParsedWithArrayColors)
{
    YAML::Node border;
    border["size"] = 2;

    YAML::Node color_node;
    color_node.push_back(255);
    color_node.push_back(155);
    color_node.push_back(155);
    color_node.push_back(255);
    border["color"] = color_node;

    YAML::Node focus_color;
    focus_color.push_back(10);
    focus_color.push_back(10);
    focus_color.push_back(10);
    focus_color.push_back(255);
    border["focus_color"] = focus_color;

    YAML::Node node;
    node["border"] = border;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_border_config().size, 2);
    EXPECT_EQ(config.get_border_config().color.r, 1.f);
    EXPECT_EQ(config.get_border_config().color.g, 155.f / 255.f);
    EXPECT_EQ(config.get_border_config().color.b, 155.f / 255.f);
    EXPECT_EQ(config.get_border_config().color.a, 1.f);
    EXPECT_EQ(config.get_border_config().focus_color.r, 10.f / 255.f);
    EXPECT_EQ(config.get_border_config().focus_color.g, 10.f / 255.f);
    EXPECT_EQ(config.get_border_config().focus_color.b, 10.f / 255.f);
    EXPECT_EQ(config.get_border_config().focus_color.a, 1.f);
}

TEST_F(FilesystemConfigurationTest, BorderCanBeParsedWithHexColor)
{
    YAML::Node border;
    border["size"] = 2;

    border["color"] = "0xDD89DDFF";

    YAML::Node focus_color;
    focus_color.push_back(10);
    focus_color.push_back(10);
    focus_color.push_back(10);
    focus_color.push_back(255);
    border["focus_color"] = focus_color;

    YAML::Node node;
    node["border"] = border;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_border_config().color.r, 221.f / 255.f);
    EXPECT_EQ(config.get_border_config().color.g, 137.f / 255.f);
    EXPECT_EQ(config.get_border_config().color.b, 221.f / 255.f);
    EXPECT_EQ(config.get_border_config().color.a, 1.f);
}

TEST_F(FilesystemConfigurationTest, BorderCanBeParsedObjectColor)
{
    YAML::Node border;
    border["size"] = 2;

    border["color"]["r"] = 15;
    border["color"]["g"] = 25;
    border["color"]["b"] = 30;
    border["color"]["a"] = 55;

    YAML::Node focus_color;
    focus_color.push_back(10);
    focus_color.push_back(10);
    focus_color.push_back(10);
    focus_color.push_back(255);
    border["focus_color"] = focus_color;

    YAML::Node node;
    node["border"] = border;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_border_config().color.r, 15.f / 255.f);
    EXPECT_EQ(config.get_border_config().color.g, 25.f / 255.f);
    EXPECT_EQ(config.get_border_config().color.b, 30.f / 255.f);
    EXPECT_EQ(config.get_border_config().color.a, 55.f / 255.f);
}

TEST_F(FilesystemConfigurationTest, DragAndDropAllValues)
{
    YAML::Node drag_and_drop;
    drag_and_drop["enabled"] = true;
    drag_and_drop["modifiers"].push_back("alt");

    YAML::Node node;
    node["drag_and_drop"] = drag_and_drop;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.drag_and_drop().enabled, true);
    EXPECT_EQ(config.drag_and_drop().modifiers, mir_input_event_modifier_alt);
}

TEST_F(FilesystemConfigurationTest, DragAndDropMissingEnabled)
{
    YAML::Node drag_and_drop;
    drag_and_drop["modifiers"].push_back("primary");

    YAML::Node node;
    node["drag_and_drop"] = drag_and_drop;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.drag_and_drop().enabled, true);
    EXPECT_EQ(config.drag_and_drop().modifiers, miracle_input_event_modifier_default);
}

TEST_F(FilesystemConfigurationTest, DragAndDropMissingModifiers)
{
    YAML::Node drag_and_drop;
    drag_and_drop["enabled"] = true;

    YAML::Node node;
    node["drag_and_drop"] = drag_and_drop;
    write_yaml_node(node);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.drag_and_drop().enabled, true);
    EXPECT_EQ(config.drag_and_drop().modifiers, miracle_input_event_modifier_default | mir_input_event_modifier_shift);
}

struct AnimationTypeParam
{
    std::string value;
    BultInAnimationType expected;
};

class FilesystemConfigurationTestAnimationTypes : public FilesystemConfigurationTest, public ::testing::WithParamInterface<AnimationTypeParam>
{
};

TEST_P(FilesystemConfigurationTestAnimationTypes, CanReadAnimationTypeInAnimationList)
{
    auto param = GetParam();
    YAML::Node list_item;
    list_item["type"] = param.value;
    list_item["function"] = "linear";

    YAML::Node list;
    list.push_back(list_item);

    YAML::Node animation;
    animation["duration"] = 1000;
    animation["event"] = "window_open";
    animation["parts"] = list;

    YAML::Node animations_node;
    animations_node.push_back(animation);

    YAML::Node root;
    root["animations"] = animations_node;
    write_yaml_node(root);

    FilesystemConfiguration config(registrar, path, true);
    auto const def = config.get_animation_definition(AnimateableEvent::window_open);
    EXPECT_EQ(def.data[0].type, param.expected);
}

TEST_F(FilesystemConfigurationTest, CanReadSimulatedSecondaryClick)
{
    YAML::Node ssc_node;
    ssc_node["enabled"] = true;
    ssc_node["hold_duration"] = 123;
    ssc_node["displacement_threshold"] = 456;

    YAML::Node root;
    root["simulated_secondary_click"] = ssc_node;
    write_yaml_node(root);

    FilesystemConfiguration config(registrar, path, true);
    auto const ssc = config.simulated_secondary_click();
    EXPECT_THAT(ssc.enabled, testing::Eq(true));
    EXPECT_THAT(ssc.hold_duration_milliseconds, testing::Eq(123));
    EXPECT_THAT(ssc.displacement_threshold, testing::Eq(456));
}

INSTANTIATE_TEST_SUITE_P(
    FilesystemConfigurationTestAnimationTypes,
    FilesystemConfigurationTestAnimationTypes,
    ::testing::Values(
        AnimationTypeParam("disabled", BultInAnimationType::disabled),
        AnimationTypeParam("slide", BultInAnimationType::slide),
        AnimationTypeParam("grow", BultInAnimationType::grow),
        AnimationTypeParam("shrink", BultInAnimationType::shrink),
        AnimationTypeParam("fade", BultInAnimationType::fade)));

TEST_F(FilesystemConfigurationTest, TriggersListenerOnReload)
{
    class Observer : public ConfigObserver
    {
    public:
        MOCK_METHOD((void), on_config_changed, (Config const&), (override));
    };

    auto const observer = std::make_shared<Observer>();
    registrar->register_interest(observer);
    EXPECT_CALL(*observer, on_config_changed).Times(1);

    FilesystemConfiguration config(registrar, path, true);
}

TEST_F(FilesystemConfigurationTest, CanReadOutputFilter)
{
    YAML::Node output_filter_node;
    output_filter_node["shader_path"] = "hello.frag";

    YAML::Node root;
    root["output_filter"] = output_filter_node;
    write_yaml_node(root);

    FilesystemConfiguration config(registrar, path, true);
    auto const output_filter = config.output_filter();
    EXPECT_THAT(output_filter.shader_path.value(), testing::Eq("hello.frag"));
}

TEST_F(FilesystemConfigurationTest, CanReadOutputFilterWithTilde)
{
    setenv("HOME", "/home/user", 1);
    YAML::Node output_filter_node;
    output_filter_node["shader_path"] = "~/hello.frag";

    YAML::Node root;
    root["output_filter"] = output_filter_node;
    write_yaml_node(root);

    FilesystemConfiguration config(registrar, path, true);
    auto const output_filter = config.output_filter();
    EXPECT_THAT(output_filter.shader_path.value(), testing::Eq("/home/user/hello.frag"));
}

TEST_F(FilesystemConfigurationTest, CanReadCursor)
{
    YAML::Node cursor_node;
    cursor_node["scale"] = 4.f;

    YAML::Node root;
    root["cursor"] = cursor_node;
    write_yaml_node(root);

    FilesystemConfiguration config(registrar, path, true);
    auto const cursor = config.cursor();
    EXPECT_THAT(cursor.scale, testing::Eq(4.f));
}

TEST_F(FilesystemConfigurationTest, CanReadSlowKeys)
{
    YAML::Node slow_keys_node;
    slow_keys_node["enabled"] = true;
    slow_keys_node["hold_delay"] = 500;

    YAML::Node root;
    root["slow_keys"] = slow_keys_node;
    write_yaml_node(root);

    FilesystemConfiguration config(registrar, path, true);
    auto const slow_keys = config.slow_keys();
    EXPECT_THAT(slow_keys.enabled, testing::Eq(true));
    EXPECT_THAT(slow_keys.hold_delay_milliseconds, testing::Eq(500));
}

TEST_F(FilesystemConfigurationTest, CanReadStickyKeys)
{
    YAML::Node sticky_keys_node;
    sticky_keys_node["enabled"] = true;
    sticky_keys_node["should_disable_if_two_keys_are_pressed_together"] = false;

    YAML::Node root;
    root["sticky_keys"] = sticky_keys_node;
    write_yaml_node(root);

    FilesystemConfiguration config(registrar, path, true);
    auto const sticky_keys = config.sticky_keys();
    EXPECT_THAT(sticky_keys.enabled, testing::Eq(true));
    EXPECT_THAT(sticky_keys.should_disable_if_two_keys_are_pressed_together, testing::Eq(false));
}

TEST_F(FilesystemConfigurationTest, CanReadTouchpad)
{
    YAML::Node touchpad_node;
    touchpad_node["disable_while_typing"] = true;
    touchpad_node["disable_with_external_mouse"] = false;
    touchpad_node["acceleration_bias"] = -0.3;
    touchpad_node["vscroll_speed"] = 1.5;
    touchpad_node["hscroll_speed"] = 0.8;
    touchpad_node["tap_to_click"] = false;
    touchpad_node["middle_mouse_button_emulation"] = true;
    touchpad_node["click_mode"] = "area_to_click";
    touchpad_node["scroll_mode"] = "edge_scroll";

    YAML::Node root;
    root["touchpad"] = touchpad_node;
    write_yaml_node(root);

    FilesystemConfiguration config(registrar, path, true);
    auto const touchpad = config.touchpad();
    EXPECT_THAT(touchpad.disable_while_typing, testing::Eq(true));
    EXPECT_THAT(touchpad.disable_with_external_mouse, testing::Eq(false));
    EXPECT_THAT(touchpad.acceleration_bias, testing::FloatEq(-0.3f));
    EXPECT_THAT(touchpad.vscroll_speed, testing::FloatEq(1.5f));
    EXPECT_THAT(touchpad.hscroll_speed, testing::FloatEq(0.8f));
    EXPECT_THAT(touchpad.tap_to_click, testing::Eq(false));
    EXPECT_THAT(touchpad.middle_mouse_button_emulation, testing::Eq(true));
    EXPECT_THAT(touchpad.click_mode, testing::Eq(mir_touchpad_click_mode_area_to_click));
    EXPECT_THAT(touchpad.scroll_mode, testing::Eq(mir_touchpad_scroll_mode_edge_scroll));
}

TEST_F(FilesystemConfigurationTest, CanReadIncludes)
{
    const std::string include_path = std::filesystem::current_path() / "test_include.yaml";

    // Write main config
    YAML::Node includes;
    includes.push_back(include_path);
    YAML::Node root;
    root["includes"] = includes;
    write_yaml_node(root);

    // Write included config
    {
        std::ofstream included_file(include_path, std::ios::trunc);
        included_file << "action_key" << ": " << "alt" << "\n";
    }

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_THAT(config.get_input_event_modifier(), testing::Eq(mir_input_event_modifier_alt));

    std::filesystem::remove(include_path.c_str());
}

TEST_F(FilesystemConfigurationTest, AutoLoadsWasmFilesFromPluginsDir)
{
    const auto plugins_dir = std::filesystem::path(path).parent_path() / "plugins";
    std::filesystem::create_directories(plugins_dir);
    std::ofstream(plugins_dir / "test.wasm").close();

    class Observer : public ConfigObserver
    {
    public:
        MOCK_METHOD((void), on_config_changed, (Config const&), (override));
        MOCK_METHOD((void), on_plugins_changed, (std::vector<PluginConfiguration> const&), (override));
    };
    auto observer = std::make_shared<Observer>();
    registrar->register_interest(observer);

    std::vector<PluginConfiguration> received;
    EXPECT_CALL(*observer, on_plugins_changed)
        .WillOnce([&](std::vector<PluginConfiguration> const& plugins)
    { received = plugins; });

    FilesystemConfiguration config(registrar, path, true);

    ASSERT_EQ(received.size(), 1u);
    EXPECT_EQ(std::filesystem::path(received[0].path).filename(), "test.wasm");

    std::filesystem::remove_all(plugins_dir);
}

TEST_F(FilesystemConfigurationTest, AutoDiscoveredPluginsLoadedAfterConfigPlugins)
{
    const auto plugins_dir = std::filesystem::path(path).parent_path() / "plugins";
    std::filesystem::create_directories(plugins_dir);
    std::ofstream(plugins_dir / "auto.wasm").close();

    YAML::Node plugin_node;
    plugin_node["path"] = "/some/config.wasm";
    YAML::Node plugins_list;
    plugins_list.push_back(plugin_node);
    YAML::Node root;
    root["plugins"] = plugins_list;
    write_yaml_node(root);

    class Observer : public ConfigObserver
    {
    public:
        MOCK_METHOD((void), on_config_changed, (Config const&), (override));
        MOCK_METHOD((void), on_plugins_changed, (std::vector<PluginConfiguration> const&), (override));
    };
    auto observer = std::make_shared<Observer>();
    registrar->register_interest(observer);

    std::vector<PluginConfiguration> received;
    EXPECT_CALL(*observer, on_plugins_changed)
        .WillOnce([&](std::vector<PluginConfiguration> const& plugins)
    { received = plugins; });

    FilesystemConfiguration config(registrar, path, true);

    ASSERT_EQ(received.size(), 2u);
    EXPECT_EQ(received[0].path, "/some/config.wasm");
    EXPECT_EQ(std::filesystem::path(received[1].path).filename(), "auto.wasm");

    std::filesystem::remove_all(plugins_dir);
}

TEST_F(FilesystemConfigurationTest, NonWasmFilesInPluginsDirAreIgnored)
{
    const auto plugins_dir = std::filesystem::path(path).parent_path() / "plugins";
    std::filesystem::create_directories(plugins_dir);
    std::ofstream(plugins_dir / "lib.so").close();
    std::ofstream(plugins_dir / "script.js").close();

    class Observer : public ConfigObserver
    {
    public:
        MOCK_METHOD((void), on_config_changed, (Config const&), (override));
        MOCK_METHOD((void), on_plugins_changed, (std::vector<PluginConfiguration> const&), (override));
    };
    auto observer = std::make_shared<Observer>();
    registrar->register_interest(observer);

    std::vector<PluginConfiguration> received;
    EXPECT_CALL(*observer, on_plugins_changed)
        .WillOnce([&](std::vector<PluginConfiguration> const& plugins)
    { received = plugins; });

    FilesystemConfiguration config(registrar, path, true);

    EXPECT_TRUE(received.empty());

    std::filesystem::remove_all(plugins_dir);
}

TEST_F(FilesystemConfigurationTest, MissingPluginsDirDoesNotCrash)
{
    EXPECT_NO_THROW(FilesystemConfiguration config(registrar, path, true));
}

TEST_F(FilesystemConfigurationTest, CleanConfigHasNoErrors)
{
    write_kvp("action_key", "alt");
    FilesystemConfiguration config(registrar, path, true);
    EXPECT_TRUE(config.get_config_errors().empty());
}

TEST_F(FilesystemConfigurationTest, ErroneousConfigRetainsErrors)
{
    // A terminal that does not resolve to an existing program produces an error.
    write_kvp("terminal", "definitely_not_a_real_program_xyz");
    FilesystemConfiguration config(registrar, path, true);
    EXPECT_FALSE(config.get_config_errors().empty());
}

TEST_F(FilesystemConfigurationTest, ReloadClearsPreviousErrors)
{
    write_kvp("terminal", "definitely_not_a_real_program_xyz");
    FilesystemConfiguration config(registrar, path, true);
    ASSERT_FALSE(config.get_config_errors().empty());

    // Replace the config with a clean one and reload.
    SetUp();
    write_kvp("action_key", "alt");
    config.reload();
    EXPECT_TRUE(config.get_config_errors().empty());
}

TEST_F(FilesystemConfigurationTest, ErrorReporterDefaultsToDefault)
{
    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_error_reporter_client(), "default");
}

TEST_F(FilesystemConfigurationTest, CanReadWmClientsErrorReporter)
{
    YAML::Node wm_clients_node;
    wm_clients_node["error_reporter"] = "disabled";

    YAML::Node root;
    root["wm_clients"] = wm_clients_node;
    write_yaml_node(root);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_error_reporter_client(), "disabled");
}

TEST_F(FilesystemConfigurationTest, DebugOverlayDefaultsToDefault)
{
    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_debug_overlay_client(), "default");
}

TEST_F(FilesystemConfigurationTest, CanReadWmClientsDebugOverlay)
{
    YAML::Node wm_clients_node;
    wm_clients_node["debug_overlay"] = "disabled";

    YAML::Node root;
    root["wm_clients"] = wm_clients_node;
    write_yaml_node(root);

    FilesystemConfiguration config(registrar, path, true);
    EXPECT_EQ(config.get_debug_overlay_client(), "disabled");
}
