/**
Copyright (C) 2025  Matthew Kosarek

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/

#ifndef MIRACLE_WM_OUTPUT_FACTORY_INTERFACE_H
#define MIRACLE_WM_OUTPUT_FACTORY_INTERFACE_H

#include <memory>
#include <mir/geometry/rectangle.h>

namespace miracle
{
class AbstractOutput;

class OutputFactoryInterface
{
public:
    virtual ~OutputFactoryInterface() = default;
    virtual std::shared_ptr<AbstractOutput> create(
        std::string name,
        int id,
        mir::geometry::Rectangle area)
        = 0;
};
}

#endif // MIRACLE_WM_OUTPUT_FACTORY_INTERFACE_H
