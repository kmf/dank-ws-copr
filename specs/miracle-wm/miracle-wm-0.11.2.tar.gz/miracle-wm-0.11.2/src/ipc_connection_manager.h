/**
Copyright (C) 2025  Matthew Kosarek

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/

#ifndef IPC_CONNECTION_H
#define IPC_CONNECTION_H

#include "binding_event_listener.h"
#include "config_observer.h"
#include "ipc_message_handler.h"
#include "mode_observer.h"
#include "output_listener.h"
#include "window_observer.h"
#include "workspace_observer.h"
#include <atomic>
#include <functional>
#include <memory>
#include <mir/fd.h>
#include <mutex>
#include <string>
#include <vector>

namespace mir
{
class MainLoop;
}

namespace miracle
{
class AbstractCommandController;
class BindingEvent;
class WindowController;
class PluginManager;

/// Manages IPC connections and routes requests to the [IpcMessageHandler].
class IpcConnectionManager : public virtual WorkspaceObserver,
                             public virtual ModeObserver,
                             public virtual WindowObserver,
                             public virtual ConfigObserver,
                             public virtual OutputListener,
                             public BindingEventListener
{
public:
    IpcConnectionManager(
        std::shared_ptr<mir::MainLoop> const& main_loop,
        std::shared_ptr<AbstractCommandController> const&,
        std::shared_ptr<IpcCommandExecutor> const&,
        std::shared_ptr<Config> const&,
        std::shared_ptr<WindowController> const&,
        std::shared_ptr<PluginManager> const&);
    ~IpcConnectionManager() override;
    void on_workspace_created(uint32_t id) override;
    void on_workspace_empty(uint32_t id) override;
    void on_workspace_removed(uint32_t id) override;
    void on_workspace_focused(std::optional<uint32_t>, uint32_t) override;
    void on_workspace_renamed(uint32_t) override;
    void on_workspace_area_changed(uint32_t) override { }
    void on_config_changed(Config const&) override;
    void on_mode_changed(WindowManagerMode mode) override;
    void on_shutdown();
    void on_window_created(Container const&) override;
    void on_window_closed(Container const&) override;
    void on_window_focused(Container const&) override;
    void on_window_fullscreen(Container const&) override;
    void on_window_move(Container const&) override;
    void on_window_float(Container const&) override;
    void on_window_marked(Container const&) override;
    void on_urgency_changed(Container const&) override;
    void output_created(miral::Output const&) override;
    void output_deleted(miral::Output const&) override;
    void output_updated(miral::Output const& updated, miral::Output const& original) override;
    void on_binding_event(BindingEvent const& binding_event) override;

    /// Publish a plugin event on \p ns to every client subscribed to that namespace.
    void on_plugin_event(std::string const& ns, std::string const& payload_json);

private:
    struct IpcClient
    {
        mir::Fd client_fd;
        uint32_t pending_read_length = 0;
        IpcType pending_type;
        std::vector<char> buffer;
        uint32_t write_buffer_len = 0;
        int subscribed_events = 0;
        std::vector<std::string> subscribed_plugin_namespaces;
    };

    std::shared_ptr<mir::MainLoop> main_loop;

    /// Guards [clients] only. It must never be held while sending to a client, because
    /// [send_reply] may disconnect that client, which erases it from [clients].
    std::mutex clients_mutex;
    std::shared_ptr<AbstractCommandController> command_controller;
    std::shared_ptr<Config> config;
    std::unique_ptr<IpcMessageHandler> ipc_message_handler;
    mir::Fd ipc_socket;
    sockaddr_un* ipc_sockaddr = nullptr;
    std::vector<std::shared_ptr<IpcClient>> clients;

    /// Union of every client's [IpcClient::subscribed_events]. Updated wherever a
    /// client subscribes or is removed, and readable from any thread, so that observers
    /// on the input thread can skip serializing payloads that no client wants.
    std::atomic<int> subscribed_events_union { 0 };

    /// Reset in the destructor so that actions still sitting on the main loop queue
    /// can detect that this manager is gone.
    std::shared_ptr<bool> alive = std::make_shared<bool>(true);

    /// Runs \p action on the main loop thread. Every mutation of a client's write buffer
    /// must happen there, otherwise events broadcast from the window management thread
    /// race with the IPC socket's read handler.
    void run_on_main_loop(std::function<void()> action);

    /// Returns a copy of [clients] so that callers may iterate without holding
    /// [clients_mutex] and without risking elements being erased mid-iteration.
    std::vector<std::shared_ptr<IpcClient>> snapshot_clients();

    /// True if at least one client is subscribed to \p type. Cheap and lock-free, so
    /// observers may call it on the input thread to skip serializing payloads nobody wants.
    [[nodiscard]] bool has_subscribers(IpcType type) const;

    /// Sends \p payload to every client subscribed to \p type, on the main loop thread.
    void broadcast(IpcType type, std::string payload);

    /// Disconnects the provided client.
    void disconnect(IpcClient& client);

    void disconnect_internal(IpcClient* client);

    /// Handles a command for the client.
    void handle_command(IpcClient& client, uint32_t payload_length, IpcType payload_type);

    /// Sends a reply to the client.
    void send_reply(IpcClient& client, IpcType command_type, std::string const& payload);

    /// Handles writeable for the client.
    void handle_writeable(IpcClient& client);

    void send_window_event(const char* event, Container const&);
    void send_output_event();
};
}

#endif // IPC_CONNECTION_H
