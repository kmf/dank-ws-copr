/**
Copyright (C) 2025  Matthew Kosarek

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
**/

#ifndef MIRACLE_MIR_VERSION_MANAGER_H
#define MIRACLE_MIR_VERSION_MANAGER_H

#include <mir/version.h>

#if ((MIR_SERVER_MAJOR_VERSION > 2) || (MIR_SERVER_MAJOR_VERSION == 2 && MIR_SERVER_MINOR_VERSION >= 24)) || COMPILING_AGAINST_DEV
#define MIR_VERSION_2_24_OR_GREATER
#endif

#if ((MIR_SERVER_MAJOR_VERSION > 2) || (MIR_SERVER_MAJOR_VERSION == 2 && MIR_SERVER_MINOR_VERSION >= 26)) || COMPILING_AGAINST_DEV
#define MIR_VERSION_2_26_OR_GREATER
#endif

#if ((MIR_SERVER_MAJOR_VERSION > 2) || (MIR_SERVER_MAJOR_VERSION == 2 && MIR_SERVER_MINOR_VERSION >= 28)) || COMPILING_AGAINST_DEV
#define MIR_VERSION_2_28_OR_GREATER
#define MIR_COMPILING_AGAINST_DEV
#endif

#if ((MIR_SERVER_MAJOR_VERSION > 2) || (MIR_SERVER_MAJOR_VERSION == 2 && MIR_SERVER_MINOR_VERSION >= 29)) || COMPILING_AGAINST_DEV
#define MIR_VERSION_2_29_OR_GREATER
#endif

#if ((MIR_SERVER_MAJOR_VERSION > 2) || (MIR_SERVER_MAJOR_VERSION == 2 && MIR_SERVER_MINOR_VERSION >= 30)) || COMPILING_AGAINST_DEV
#define MIR_VERSION_2_30_OR_GREATER
#endif

#endif // MIRACLE_MIR_VERSION_MANAGER_H
